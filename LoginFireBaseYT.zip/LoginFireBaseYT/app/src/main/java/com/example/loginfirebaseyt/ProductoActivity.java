package com.example.loginfirebaseyt;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class ProductoActivity extends AppCompatActivity {
    EditText codigo, nombre, stock, precioCosto, precioVenta;
    Button guardar, buscar, actualizar, borrar, btnRegresar;
    DatabaseReference productosDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_producto);

        codigo = findViewById(R.id.etCodigo);
        nombre = findViewById(R.id.etNombre);
        stock = findViewById(R.id.etStock);
        precioCosto = findViewById(R.id.etPrecioCosto);
        precioVenta = findViewById(R.id.etPrecioVenta);
        guardar = findViewById(R.id.btnGuardar);
        buscar = findViewById(R.id.btnBuscar);
        actualizar = findViewById(R.id.btnActualizar);
        borrar = findViewById(R.id.btnBorrar);
        btnRegresar = findViewById(R.id.btnRegresar);


        productosDB = FirebaseDatabase.getInstance().getReference("productos");

        guardar.setOnClickListener(v -> {
            String cod = codigo.getText().toString();
            Map<String, Object> producto = new HashMap<>();
            producto.put("nombre", nombre.getText().toString());
            producto.put("stock", Integer.parseInt(stock.getText().toString()));
            producto.put("precioCosto", Double.parseDouble(precioCosto.getText().toString()));
            producto.put("precioVenta", Double.parseDouble(precioVenta.getText().toString()));
            productosDB.child(cod).setValue(producto);
            Toast.makeText(this, "Guardado con exito", Toast.LENGTH_SHORT).show();


        });



        buscar.setOnClickListener(v -> {
            String cod = codigo.getText().toString();
            productosDB.child(cod).get().addOnSuccessListener(snapshot -> {
                if (snapshot.exists()) {
                    nombre.setText(snapshot.child("nombre").getValue(String.class));
                    stock.setText(String.valueOf(snapshot.child("stock").getValue(Long.class)));
                    precioCosto.setText(String.valueOf(snapshot.child("precioCosto").getValue(Double.class)));
                    precioVenta.setText(String.valueOf(snapshot.child("precioVenta").getValue(Double.class)));
                } else {
                    Toast.makeText(this, "No encontrado. Verifica el codigo del producto", Toast.LENGTH_SHORT).show();
                }
            });
        });

        actualizar.setOnClickListener(v -> {
            guardar.performClick();
            Toast.makeText(this, "Actualizado con exito", Toast.LENGTH_SHORT).show();
        });

        borrar.setOnClickListener(v -> {
            productosDB.child(codigo.getText().toString()).removeValue();
            Toast.makeText(this, "Eliminado con exito", Toast.LENGTH_SHORT).show();
        });
        btnRegresar.setOnClickListener(v -> {
            startActivity(new Intent(ProductoActivity.this, MainActivity.class));
            finish(); // Cierra esta actividad
        });
    }
}