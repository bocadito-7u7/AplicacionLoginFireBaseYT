package com.example.loginfirebaseyt;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    EditText email, password;
    Spinner spinner;
    Button login;
    Button  btnRegistrar;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email = findViewById(R.id.etCorreo);
        password = findViewById(R.id.etPassword);
        spinner = findViewById(R.id.spinner);
        login = findViewById(R.id.btnLogin);
        btnRegistrar = findViewById(R.id.btnRegistrar);
        mAuth = FirebaseAuth.getInstance();

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.opciones_login, android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);

        login.setOnClickListener(v -> {
            String correo = email.getText().toString();
            String pass = password.getText().toString();

            if (correo.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Campos vacíos. Rellene sus datos para poder ingresar", Toast.LENGTH_SHORT).show();
                return;
            }

            mAuth.signInWithEmailAndPassword(correo, pass).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    String opcion = spinner.getSelectedItem().toString();
                    switch (opcion) {
                        case "Persona":
                            startActivity(new Intent(this, PersonaActivity.class));
                            break;
                        case "Producto":
                            startActivity(new Intent(this, ProductoActivity.class));
                            break;
                        case "Inventario":
                            startActivity(new Intent(this, InventarioActivity.class));
                            break;
                    }
                } else {
                    Toast.makeText(this, "Login fallido. Verifique sus datos", Toast.LENGTH_SHORT).show();
                }
            });
        });
        btnRegistrar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }
}
